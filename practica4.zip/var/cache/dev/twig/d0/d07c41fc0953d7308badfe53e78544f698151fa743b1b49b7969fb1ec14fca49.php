<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* usuarios/_form.html.twig */
class __TwigTemplate_b0a3479fe8f2525b21a37e5d180262b42a5b287469c857bd70ded07dbed8ccee extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "usuarios/_form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "usuarios/_form.html.twig"));

        // line 1
        echo "

";
        // line 3
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 3, $this->source); })()), 'form_start', ["attr" => ["class" => "form-signin"]]);
        echo "
    ";
        // line 5
        echo "    
    <div class=\"form-group\">
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 7, $this->source); })()), "Nombre", [], "any", false, false, false, 7), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 10, $this->source); })()), "Apellidos", [], "any", false, false, false, 10), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 13, $this->source); })()), "Nacimiento", [], "any", false, false, false, 13), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 16, $this->source); })()), "Sexo", [], "any", false, false, false, 16), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 19, $this->source); })()), "Ciudad", [], "any", false, false, false, 19), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    <div class=\"form-group\">
        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 22, $this->source); })()), "Aficiones", [], "any", false, false, false, 22), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
    </div>
    ";
        // line 24
        if (0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 24, $this->source); })()), "imagen", [], "any", false, false, false, 24), null)) {
            // line 25
            echo "        <div class=\"form-group\">
            <img src=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("data/imagenes/" . twig_get_attribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 26, $this->source); })()), "imagen", [], "any", false, false, false, 26))), "html", null, true);
            echo "\" width=\"80\">
            <a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("borrar_foto", ["imagen" => twig_get_attribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 27, $this->source); })()), "imagen", [], "any", false, false, false, 27), "usuario" => twig_get_attribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 27, $this->source); })()), "id", [], "any", false, false, false, 27)]), "html", null, true);
            echo "\" class=\"btn btn-lg eliminar btn-danger\" onclick=\"return confirm('¿Seguro que quieres borrar la foto?');\">Eliminar Foto</a>          
        </div>
    ";
        }
        // line 30
        echo "        <div class=\"form-group\">
            ";
        // line 31
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 31, $this->source); })()), "imagen", [], "any", false, false, false, 31), 'row', ["attr" => ["class" => "form-control"]]);
        echo "
        </div>
    <button class=\"btn btn-lg btn-primary btn-block\">";
        // line 33
        echo twig_escape_filter($this->env, (((isset($context["button_label"]) || array_key_exists("button_label", $context))) ? (_twig_default_filter((isset($context["button_label"]) || array_key_exists("button_label", $context) ? $context["button_label"] : (function () { throw new RuntimeError('Variable "button_label" does not exist.', 33, $this->source); })()), "Agregar usuario")) : ("Agregar usuario")), "html", null, true);
        echo "</button>
";
        // line 34
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), 'form_end');
        echo "



";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "usuarios/_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 34,  113 => 33,  108 => 31,  105 => 30,  99 => 27,  95 => 26,  92 => 25,  90 => 24,  85 => 22,  79 => 19,  73 => 16,  67 => 13,  61 => 10,  55 => 7,  51 => 5,  47 => 3,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("

{{ form_start(form, {'attr': {'class': 'form-signin'}} ) }}
    {# <h2 class=\"h3 mb-3 font-weight-normal\">Agregando un usuario</h2> #}
    
    <div class=\"form-group\">
        {{ form_row(form.Nombre, {'attr': {'class': 'form-control'}}) }}
    </div>
    <div class=\"form-group\">
        {{ form_row(form.Apellidos, {'attr': {'class': 'form-control'}}) }}
    </div>
    <div class=\"form-group\">
        {{ form_row(form.Nacimiento, {'attr': {'class': 'form-control'}}) }}
    </div>
    <div class=\"form-group\">
        {{ form_row(form.Sexo, {'attr': {'class': 'form-control'}}) }}
    </div>
    <div class=\"form-group\">
        {{ form_row(form.Ciudad, {'attr': {'class': 'form-control'}}) }}
    </div>
    <div class=\"form-group\">
        {{ form_row(form.Aficiones, {'attr': {'class': 'form-control'}}) }}
    </div>
    {% if usuario.imagen != null %}
        <div class=\"form-group\">
            <img src=\"{{ asset('data/imagenes/'~usuario.imagen) }}\" width=\"80\">
            <a href=\"{{ path('borrar_foto', {imagen: usuario.imagen, usuario: usuario.id}) }}\" class=\"btn btn-lg eliminar btn-danger\" onclick=\"return confirm('¿Seguro que quieres borrar la foto?');\">Eliminar Foto</a>          
        </div>
    {% endif %}
        <div class=\"form-group\">
            {{ form_row(form.imagen, {'attr': {'class': 'form-control'}}) }}
        </div>
    <button class=\"btn btn-lg btn-primary btn-block\">{{ button_label|default('Agregar usuario') }}</button>
{{ form_end(form) }}



", "usuarios/_form.html.twig", "/home/ubuntu/yuriy/practica4/templates/usuarios/_form.html.twig");
    }
}
